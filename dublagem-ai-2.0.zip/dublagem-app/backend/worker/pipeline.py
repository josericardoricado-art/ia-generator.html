#!/usr/bin/env python3
import argparse,subprocess,sys,os,tempfile

def stage(x): print('STAGE:'+x,flush=True)
def progress(x): print('PROGRESS:'+str(x),flush=True)
def run(cmd): return subprocess.run(cmd,check=True,capture_output=True)
def extract(video,audio): stage('extraindo áudio');progress(5);run(['ffmpeg','-y','-i',video,'-vn','-acodec','pcm_s16le','-ar','16000','-ac','1',audio])
def transcribe(audio):
 stage('transcrevendo com Whisper');progress(20);import whisper
 model=whisper.load_model(os.getenv('WHISPER_MODEL','small'));r=model.transcribe(audio);return r['text'],r.get('language','en')
def translate(text,src,dst):
 stage(f'traduzindo {src} → {dst}');progress(45);import argostranslate.translate
 return argostranslate.translate.translate(text,src,dst)
def tts(text,lang,out,mode,speaker):
 stage('gerando voz dublada');progress(70);from TTS.api import TTS
 t=TTS(model_name='tts_models/multilingual/multi-dataset/xtts_v2',progress_bar=False)
 kw={'text':text,'language':lang,'file_path':out}
 if mode=='clone' and speaker: kw['speaker_wav']=speaker
 else: kw['speaker']='Claribel Dervla'
 t.tts_to_file(**kw)
def merge(video,audio,out):
 stage('montando vídeo final');progress(90);run(['ffmpeg','-y','-i',video,'-i',audio,'-map','0:v:0','-map','1:a:0','-c:v','copy','-shortest',out])
def main():
 p=argparse.ArgumentParser();p.add_argument('--input',required=True);p.add_argument('--output',required=True);p.add_argument('--target-lang',default='pt');p.add_argument('--voice-mode',choices=['standard','clone'],default='standard');p.add_argument('--speaker-wav');a=p.parse_args()
 with tempfile.TemporaryDirectory() as d:
  ai=os.path.join(d,'in.wav');ao=os.path.join(d,'out.wav')
  try:
   extract(a.input,ai);text,src=transcribe(ai)
   if not text.strip():raise RuntimeError('Não foi possível reconhecer a fala.')
   translated=translate(text,src,a.target_lang);tts(translated,a.target_lang,ao,a.voice_mode,a.speaker_wav);merge(a.input,ao,a.output);progress(100);stage('concluído')
  except Exception as e:sys.stderr.write('Erro no pipeline: '+str(e)+'\n');sys.exit(1)
if __name__=='__main__':main()
